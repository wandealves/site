## jQuery plugin to create Range Selector

![jRange Preview](http://i.imgur.com/da8uZwx.png)

[Demo and Documentation](http://nitinhayaran.github.io/jRange/demo/)